
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

# Les données d'entées
ds = dataiku.Dataset("CAC_40_Time_Series_CAC_40__FCHI__")
df = ds.get_dataframe()

# 1. Conversion et tri des dates
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True, errors='coerce')
df = df.sort_values('Date')

# 2. Prétraitement des colonnes numériques (nettoyage et conversion en format numérique)
cols_to_clean = ['Price']
for col in cols_to_clean:
    df[col] = df[col].str.replace(',', '').str.strip()
    df[col] = pd.to_numeric(df[col], errors='coerce')

# 3. Calcul du log-return
df['log_return'] = np.log(df['Price'] / df['Price'].shift(1))

# 4. les données de sortie
output = dataiku.Dataset("Test")
output.write_with_schema(df)

# 5. Visualisation : série temporelle des rendements logarithmiques

# ========== Graphique des log-returns originaux ==========
plt.figure(figsize=(13, 6))
plt.plot(df['Date'], df['log_return'], color='red', label='Monthly log-change in index level')
plt.axhline(0, color='black', linestyle='--', linewidth=0.7)

plt.title("Monthly Log-Returns of CAC 40 Total Return Index", fontsize=14, weight="bold")
plt.xlabel("Date")
plt.ylabel("Log-return")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.gca().xaxis.set_major_locator(mdates.YearLocator(2))
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
plt.tight_layout()

folder = dataiku.Folder("output_folder")
with folder.get_writer("log_returns_cac40_original.png") as w:
    plt.savefig(w, format='png', dpi=300)


# ========== Série centrée (demeaned) pour comparaison ==========
df['log_return_demeaned'] = df['log_return'] - df['log_return'].mean()

plt.figure(figsize=(13, 6))
plt.plot(df['Date'], df['log_return'], color='red', label='Monthly log-change in index level')
plt.plot(df['Date'], df['log_return_demeaned'], color='navy', label='Monthly log-shocks (demeaned)')
plt.axhline(0, color='black', linestyle='--', linewidth=0.7)

plt.title("Figure: Demeaned Log-Returns Time Series - CAC 40", fontsize=14, weight="bold")
plt.xlabel("Date")
plt.ylabel("Log-return")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.gca().xaxis.set_major_locator(mdates.YearLocator(2))
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
plt.tight_layout()

with folder.get_writer("log_returns_cac40_demeaned.png") as w:
    plt.savefig(w, format='png', dpi=300)


# ========== Histogramme des log-returns ==========
plt.figure(figsize=(10, 6))
plt.hist(df['log_return'].dropna(), bins=50, color='steelblue', edgecolor='black', alpha=0.7)
plt.title("Histogramme des log-rendements mensuels - CAC 40", fontsize=14, weight="bold")
plt.xlabel("Log-return mensuel")
plt.ylabel("Nombre d’occurrences")
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()

with folder.get_writer("histogram_log_returns_cac40.png") as w:
    plt.savefig(w, format='png', dpi=300)
